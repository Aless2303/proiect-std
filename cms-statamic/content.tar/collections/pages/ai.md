---
title: Aplicație IA
layout: default
url: /ai
---

# Aplicație IA

<div class="iframe-wrapper">
    <iframe src="http://localhost:8080"></iframe>
</div>